package com.diario.projetodiario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetodiarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetodiarioApplication.class, args);
	}

}
