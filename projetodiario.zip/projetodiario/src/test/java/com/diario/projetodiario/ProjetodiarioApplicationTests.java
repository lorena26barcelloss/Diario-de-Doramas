package com.diario.projetodiario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetodiarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
